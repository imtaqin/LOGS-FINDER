using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LogsFinder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (var folderDialog = new FolderBrowserDialog())
            {
                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    txtFolderPath.Text = folderDialog.SelectedPath;
                }
            }
        }

        private async void btnSearch_Click(object sender, EventArgs e)
        {
            string folderPath = txtFolderPath.Text;
            string regexPattern = txtRegex.Text;

            if (Directory.Exists(folderPath))
            {
                rtbResults.Clear();
                btnSearch.Enabled = false; // Disable the button to prevent multiple clicks during the search
                await Task.Run(() => SearchFiles(folderPath, regexPattern));
                btnSearch.Enabled = true; // Re-enable the button after search
            }
            else
            {
                MessageBox.Show("Please select a valid folder.");
            }
        }

        private void SearchFiles(string folderPath, string regexPattern)
        {
            var files = Directory.EnumerateFiles(folderPath, "*.*", SearchOption.AllDirectories);
            Regex regex = new Regex(regexPattern, RegexOptions.Singleline);

            Parallel.ForEach(files, file =>
            {
                if (file.ToLower().Contains("passwords.txt") || file.ToLower().Contains("password.txt"))
                {
                    string fileContent = File.ReadAllText(file);
                    MatchCollection matches = regex.Matches(fileContent);

                    foreach (Match match in matches)
                    {
                        string result = $"URL:{match.Groups[1].Value}:USER:{match.Groups[2].Value}:PASS:{match.Groups[3].Value}";

                        // Invoke the UI update on the main thread
                        Invoke((Action)(() =>
                        {
                            rtbResults.AppendText(result + Environment.NewLine);
                        }));
                    }
                }
            });
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveDialog = new SaveFileDialog())
            {
                saveDialog.Filter = "Text Files (*.txt)|*.txt";
                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveDialog.FileName, rtbResults.Text);
                    MessageBox.Show("Results saved successfully!");
                }
            }
        }
    }
}
