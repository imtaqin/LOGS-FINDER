﻿namespace LogsFinder
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtFolderPath;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.RichTextBox rtbResults;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblFolder;
        private System.Windows.Forms.Label lblRegex;
        private System.Windows.Forms.TextBox txtRegex;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btnBrowse = new Button();
            txtFolderPath = new TextBox();
            btnSearch = new Button();
            rtbResults = new RichTextBox();
            btnSave = new Button();
            lblFolder = new Label();
            lblRegex = new Label();
            txtRegex = new TextBox();
            SuspendLayout();
            // 
            // btnBrowse
            // 
            btnBrowse.BackColor = Color.Black;
            btnBrowse.FlatStyle = FlatStyle.Flat;
            btnBrowse.Font = new Font("Consolas", 10F);
            btnBrowse.ForeColor = Color.Lime;
            btnBrowse.Location = new Point(320, 30);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(75, 23);
            btnBrowse.TabIndex = 0;
            btnBrowse.Text = "Browse";
            btnBrowse.UseVisualStyleBackColor = false;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // txtFolderPath
            // 
            txtFolderPath.BackColor = Color.Black;
            txtFolderPath.Font = new Font("Consolas", 10F);
            txtFolderPath.ForeColor = Color.Lime;
            txtFolderPath.Location = new Point(30, 30);
            txtFolderPath.Name = "txtFolderPath";
            txtFolderPath.Size = new Size(280, 23);
            txtFolderPath.TabIndex = 1;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.Black;
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Consolas", 10F);
            btnSearch.ForeColor = Color.Lime;
            btnSearch.Location = new Point(320, 80);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 2;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = false;
            btnSearch.Click += btnSearch_Click;
            // 
            // rtbResults
            // 
            rtbResults.BackColor = Color.Black;
            rtbResults.Font = new Font("Consolas", 10F);
            rtbResults.ForeColor = Color.Lime;
            rtbResults.Location = new Point(30, 130);
            rtbResults.Name = "rtbResults";
            rtbResults.Size = new Size(365, 150);
            rtbResults.TabIndex = 3;
            rtbResults.Text = "";
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.Black;
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Font = new Font("Consolas", 10F);
            btnSave.ForeColor = Color.Lime;
            btnSave.Location = new Point(320, 290);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 4;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            // 
            // lblFolder
            // 
            lblFolder.AutoSize = true;
            lblFolder.Font = new Font("Consolas", 10F);
            lblFolder.ForeColor = Color.Lime;
            lblFolder.Location = new Point(30, 10);
            lblFolder.Name = "lblFolder";
            lblFolder.Size = new Size(104, 17);
            lblFolder.TabIndex = 5;
            lblFolder.Text = "Folder Path:";
            // 
            // lblRegex
            // 
            lblRegex.AutoSize = true;
            lblRegex.Font = new Font("Consolas", 10F);
            lblRegex.ForeColor = Color.Lime;
            lblRegex.Location = new Point(30, 60);
            lblRegex.Name = "lblRegex";
            lblRegex.Size = new Size(176, 17);
            lblRegex.TabIndex = 6;
            lblRegex.Text = "Regex for extracting:";
            // 
            // txtRegex
            // 
            txtRegex.BackColor = Color.Black;
            txtRegex.Font = new Font("Consolas", 10F);
            txtRegex.ForeColor = Color.Lime;
            txtRegex.Location = new Point(30, 80);
            txtRegex.Name = "txtRegex";
            txtRegex.Size = new Size(280, 23);
            txtRegex.TabIndex = 7;
            txtRegex.Text = "SOFT:.*?\\nURL:(.*?)\\nUSER:(.*?)\\nPASS:(.*?)\\n";
            // 
            // Form1
            // 
            BackColor = Color.Black;
            ClientSize = new Size(420, 330);
            Controls.Add(txtRegex);
            Controls.Add(lblRegex);
            Controls.Add(lblFolder);
            Controls.Add(btnSave);
            Controls.Add(rtbResults);
            Controls.Add(btnSearch);
            Controls.Add(txtFolderPath);
            Controls.Add(btnBrowse);
            ForeColor = Color.Lime;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Logs Extractor : iz666";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
